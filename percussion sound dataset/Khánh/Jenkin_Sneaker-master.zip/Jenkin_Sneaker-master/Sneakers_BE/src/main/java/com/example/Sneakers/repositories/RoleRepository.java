package com.example.Sneakers.repositories;

import com.example.Sneakers.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Long> {

}
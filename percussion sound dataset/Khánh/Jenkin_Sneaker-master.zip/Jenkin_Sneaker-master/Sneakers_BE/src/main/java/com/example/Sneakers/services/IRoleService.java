package com.example.Sneakers.services;

import com.example.Sneakers.models.Role;

import java.util.List;

public interface IRoleService {
    List<Role> getAllRoles();
}
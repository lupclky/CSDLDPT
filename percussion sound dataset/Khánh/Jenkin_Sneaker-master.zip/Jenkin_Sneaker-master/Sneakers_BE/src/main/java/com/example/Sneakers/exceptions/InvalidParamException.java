package com.example.Sneakers.exceptions;

public class InvalidParamException extends Exception{
    public InvalidParamException(String message){
        super(message);
    }
}
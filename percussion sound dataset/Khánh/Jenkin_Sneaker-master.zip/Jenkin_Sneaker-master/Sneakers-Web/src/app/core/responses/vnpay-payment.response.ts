export interface VnpayPaymentResponse {
    status: string;
    message: string;
    url: string;
} 
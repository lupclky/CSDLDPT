export interface ProductToCartDto {
    product_id : number,
    quantity : number,
    size : number
}
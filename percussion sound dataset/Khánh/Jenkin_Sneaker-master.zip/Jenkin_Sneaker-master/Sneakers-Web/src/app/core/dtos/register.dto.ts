export interface registerDto {
    message : string,
}
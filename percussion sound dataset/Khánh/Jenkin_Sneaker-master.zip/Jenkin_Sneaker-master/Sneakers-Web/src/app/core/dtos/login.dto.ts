export interface loginDetailDto {
    message : string,
    token : string,
}
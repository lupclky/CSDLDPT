export interface registerReq {
    fullname: string,
    phone_number: string,
    address: string,
    password: string,
    retype_password: string,
    date_of_birth: Date,
    email: string
}
export interface CreateVnpayPaymentDto {
    amount: number;
    order_info: string;
    order_id: number;
} 
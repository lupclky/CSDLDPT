export interface CategoriesDto {
    id: number,
    name: string
}
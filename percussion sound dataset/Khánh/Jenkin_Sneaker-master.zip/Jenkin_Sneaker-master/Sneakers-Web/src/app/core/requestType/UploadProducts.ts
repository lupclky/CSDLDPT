export interface ProductUploadReq {
    name : string,
    price : number,
    category_id : number,
    description: string,
    discount: number,
    quantity: number,
}
import { CustomRequiredDirective } from './custom-required.directive';

describe('CustomRequiredDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomRequiredDirective();
    expect(directive).toBeTruthy();
  });
});

export interface loginReq {
    phone_number : string,
    password : string,
    role_id? : number,
}
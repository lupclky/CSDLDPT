export const environment = {
    production: true,
    apiUrl: 'http://localhost:8089/api/v1',
    apiImage: 'http://localhost:8089/api/v1/products/images/'
};
